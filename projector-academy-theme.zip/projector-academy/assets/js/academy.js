/* Projector Academy — header menu toggle and "On this page" highlighting. */
( function () {
	'use strict';

	var header = document.getElementById( 'pa-header' );
	var toggle = header && header.querySelector( '.pa-nav-toggle' );

	if ( toggle ) {
		toggle.addEventListener( 'click', function () {
			var open = header.classList.toggle( 'pa-nav-open' );
			toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		} );

		header.addEventListener( 'click', function ( event ) {
			if ( event.target.closest( '.pa-menu a' ) ) {
				header.classList.remove( 'pa-nav-open' );
				toggle.setAttribute( 'aria-expanded', 'false' );
			}
		} );
	}

	// Deep links to an accordion item (#create-account) open it.
	function openFromHash() {
		if ( ! window.location.hash ) {
			return;
		}
		var target = document.getElementById( decodeURIComponent( window.location.hash.slice( 1 ) ) );
		var item = target && target.closest( 'details' );
		if ( item && ! item.open ) {
			var summary = item.querySelector( 'summary' );
			if ( summary ) {
				summary.click();
			}
			window.setTimeout( function () {
				item.scrollIntoView( { block: 'start' } );
			}, 450 );
		}
	}
	window.addEventListener( 'hashchange', openFromHash );
	window.addEventListener( 'load', openFromHash );

	var toc = document.querySelector( '.pa-toc' );
	if ( ! toc ) {
		return;
	}

	var items = [];
	toc.querySelectorAll( '.elementor-icon-list-item a[href*="#"]' ).forEach( function ( link ) {
		var url = new URL( link.getAttribute( 'href' ), window.location.href );
		if ( url.pathname !== window.location.pathname || ! url.hash ) {
			return;
		}
		var target = document.getElementById( decodeURIComponent( url.hash.slice( 1 ) ) );
		if ( target ) {
			items.push( { item: link.closest( '.elementor-icon-list-item' ), target: target } );
		}
	} );

	if ( ! items.length ) {
		return;
	}

	var ticking = false;

	// Highlight the last section whose top has passed just below the floating header.
	function update() {
		var offset = 150;
		var current = items[ 0 ];
		items.forEach( function ( entry ) {
			if ( entry.target.getBoundingClientRect().top - offset <= 0 ) {
				current = entry;
			}
		} );
		var doc = document.documentElement;
		if ( window.innerHeight + window.scrollY >= doc.scrollHeight - 4 ) {
			current = items[ items.length - 1 ];
		}
		items.forEach( function ( entry ) {
			entry.item.classList.toggle( 'is-active', entry === current );
		} );
	}

	window.addEventListener(
		'scroll',
		function () {
			if ( ! ticking ) {
				ticking = true;
				window.requestAnimationFrame( function () {
					update();
					ticking = false;
				} );
			}
		},
		{ passive: true }
	);
	window.addEventListener( 'resize', update );
	update();
} )();
