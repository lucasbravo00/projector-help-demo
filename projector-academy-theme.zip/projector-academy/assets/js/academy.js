/* Projector Academy — header menu toggle and "On this page" highlighting. */
( function () {
	'use strict';

	var header = document.getElementById( 'pa-header' );
	var toggle = header && header.querySelector( '.pa-nav-toggle' );

	if ( toggle ) {
		toggle.addEventListener( 'click', function () {
			var open = header.classList.toggle( 'pa-nav-open' );
			toggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		} );

		header.addEventListener( 'click', function ( event ) {
			if ( event.target.closest( '.pa-menu a' ) ) {
				header.classList.remove( 'pa-nav-open' );
				toggle.setAttribute( 'aria-expanded', 'false' );
			}
		} );
	}

	// Only one accordion item open per page: opening an item closes any open item in the
	// page's other accordions (Elementor already handles items within the same accordion).
	document.addEventListener(
		'click',
		function ( event ) {
			var summary = event.target.closest( 'summary.e-n-accordion-item-title' );
			if ( ! summary ) {
				return;
			}
			var item = summary.closest( 'details' );
			if ( ! item || item.open ) {
				return; // This click closes the item; nothing else to do.
			}
			var accordion = item.closest( '.e-n-accordion' );
			document.querySelectorAll( 'details.e-n-accordion-item[open]' ).forEach( function ( other ) {
				if ( other !== item && other.closest( '.e-n-accordion' ) !== accordion ) {
					var otherSummary = other.querySelector( 'summary' );
					if ( otherSummary ) {
						otherSummary.click();
					}
				}
			} );
		},
		true
	);

	// Deep links to an accordion item (#create-account) open it.
	function openFromHash() {
		if ( ! window.location.hash ) {
			return;
		}
		var target = document.getElementById( decodeURIComponent( window.location.hash.slice( 1 ) ) );
		var item = target && target.closest( 'details' );
		if ( item && ! item.open ) {
			var summary = item.querySelector( 'summary' );
			if ( summary ) {
				summary.click();
			}
			window.setTimeout( function () {
				item.scrollIntoView( { block: 'start' } );
			}, 450 );
		}
	}
	window.addEventListener( 'hashchange', openFromHash );
	window.addEventListener( 'load', openFromHash );

	var toc = document.querySelector( '.pa-toc' );
	if ( ! toc ) {
		return;
	}

	// Help Center on phones in portrait: "On this page" collapses into a bar that shows the
	// current section and opens the list on demand.
	var tocToggle = null;
	var tocCurrent = null;
	var phonePortrait = window.matchMedia( '(max-width: 767px)' );
	if ( document.body.classList.contains( 'pa-site--help' ) ) {
		var tocTitle = toc.querySelector( '.pa-toc-title' );
		tocToggle = document.createElement( 'button' );
		tocToggle.type = 'button';
		tocToggle.className = 'pa-toc-toggle';
		tocToggle.setAttribute( 'aria-expanded', 'false' );
		tocToggle.innerHTML =
			'<span class="pa-toc-toggle-text"><span class="pa-toc-toggle-label"></span><span class="pa-toc-toggle-current"></span></span>' +
			'<span class="pa-toc-toggle-icon" aria-hidden="true"><svg viewBox="0 0 24 24" width="14" height="14" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg></span>';
		tocToggle.querySelector( '.pa-toc-toggle-label' ).textContent = tocTitle ? tocTitle.textContent.trim() : 'On this page';
		tocCurrent = tocToggle.querySelector( '.pa-toc-toggle-current' );
		toc.insertBefore( tocToggle, toc.firstChild );
		toc.classList.add( 'has-toggle' );

		var setOpen = function ( open ) {
			toc.classList.toggle( 'is-open', open );
			tocToggle.setAttribute( 'aria-expanded', open ? 'true' : 'false' );
		};
		tocToggle.addEventListener( 'click', function () {
			setOpen( ! toc.classList.contains( 'is-open' ) );
		} );
		toc.addEventListener( 'click', function ( event ) {
			if ( phonePortrait.matches && event.target.closest( '.elementor-icon-list-item a' ) ) {
				setOpen( false );
			}
		} );
	}

	var items = [];
	toc.querySelectorAll( '.elementor-icon-list-item a[href*="#"]' ).forEach( function ( link ) {
		var url = new URL( link.getAttribute( 'href' ), window.location.href );
		if ( url.pathname !== window.location.pathname || ! url.hash ) {
			return;
		}
		var target = document.getElementById( decodeURIComponent( url.hash.slice( 1 ) ) );
		if ( target ) {
			items.push( { item: link.closest( '.elementor-icon-list-item' ), target: target } );
		}
	} );

	if ( ! items.length ) {
		return;
	}

	var ticking = false;

	// Highlight the last section whose top has passed just below the floating header.
	function update() {
		var offset = 150;
		var current = items[ 0 ];
		items.forEach( function ( entry ) {
			if ( entry.target.getBoundingClientRect().top - offset <= 0 ) {
				current = entry;
			}
		} );
		var doc = document.documentElement;
		if ( window.innerHeight + window.scrollY >= doc.scrollHeight - 4 ) {
			current = items[ items.length - 1 ];
		}
		items.forEach( function ( entry ) {
			entry.item.classList.toggle( 'is-active', entry === current );
		} );
		if ( tocCurrent ) {
			tocCurrent.textContent = current.item.textContent.trim();
		}
	}

	window.addEventListener(
		'scroll',
		function () {
			if ( ! ticking ) {
				ticking = true;
				window.requestAnimationFrame( function () {
					update();
					ticking = false;
				} );
			}
		},
		{ passive: true }
	);
	window.addEventListener( 'resize', update );
	update();
} )();
