<?php
/**
 * Site header: floating glass bar modelled on the Projector app's top bar.
 *
 * @package ProjectorAcademy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">
	<?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>
<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'projector-academy' ); ?></a>

<header class="pa-header" id="pa-header">
	<div class="pa-bar">
		<a class="pa-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>" aria-label="<?php echo esc_attr( get_bloginfo( 'name' ) ); ?>">
			<img class="pa-brand-logo" src="<?php echo esc_url( PA_THEME_URI . '/assets/img/projector-logo-white.png' ); ?>" alt="Projector" width="132" height="46">
			<span class="pa-brand-tag"><?php echo esc_html( get_theme_mod( 'pa_brand_tag', 'Academy' ) ); ?></span>
		</a>

		<button class="pa-nav-toggle" type="button" aria-expanded="false" aria-controls="pa-nav">
			<span class="screen-reader-text"><?php esc_html_e( 'Menu', 'projector-academy' ); ?></span>
			<svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true"><path class="pa-i-open" d="M4 7h16M4 12h16M4 17h16" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/><path class="pa-i-close" d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round" fill="none"/></svg>
		</button>

		<nav class="pa-nav" id="pa-nav" aria-label="<?php esc_attr_e( 'Main', 'projector-academy' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'pa-primary',
					'container'      => false,
					'menu_class'     => 'pa-menu',
					'fallback_cb'    => false,
					'depth'          => 1,
				)
			);
			?>
		</nav>
	</div>
</header>
<div id="content" class="pa-content">
