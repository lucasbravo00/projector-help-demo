<?php
/**
 * Site footer.
 *
 * @package ProjectorAcademy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
</div><!-- #content -->

<footer class="pa-footer">
	<div class="pa-footer-inner">
		<div class="pa-footer-brand">
			<a class="pa-brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
				<img class="pa-brand-logo" src="<?php echo esc_url( PA_THEME_URI . '/assets/img/projector-logo-white.png' ); ?>" alt="Projector" width="132" height="46">
				<span class="pa-brand-tag"><?php echo esc_html( get_theme_mod( 'pa_brand_tag', 'Academy' ) ); ?></span>
			</a>
			<?php $pa_footer_text = get_theme_mod( 'pa_footer_text', 'Projector Academy is a resource for all Projector Authorized Affiliate Members.' ); ?>
			<?php if ( $pa_footer_text ) : ?>
				<p><?php echo esc_html( $pa_footer_text ); ?></p>
			<?php endif; ?>
		</div>

		<nav class="pa-footer-nav" aria-label="<?php esc_attr_e( 'Footer', 'projector-academy' ); ?>">
			<?php
			wp_nav_menu(
				array(
					'theme_location' => 'pa-footer',
					'container'      => false,
					'menu_class'     => 'pa-footer-menu',
					'fallback_cb'    => false,
					'depth'          => 1,
				)
			);
			?>
		</nav>

		<ul class="pa-social" aria-label="<?php esc_attr_e( 'Projector on social media', 'projector-academy' ); ?>">
			<?php foreach ( pa_social_links() as $social ) : ?>
				<li>
					<a href="<?php echo esc_url( $social['url'] ); ?>" target="_blank" rel="noopener noreferrer">
						<?php echo pa_social_icon( $social['icon'] ); // phpcs:ignore WordPress.Security.EscapeOutput -- static SVG. ?>
						<span class="screen-reader-text"><?php echo esc_html( sprintf( /* translators: %s: network name */ __( 'Open %s in a new tab', 'projector-academy' ), $social['label'] ) ); ?></span>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
	<div class="pa-footer-legal">
		<?php
		$pa_copyright = get_theme_mod( 'pa_copyright', '' );
		$pa_copyright = $pa_copyright ? str_replace( '{year}', gmdate( 'Y' ), $pa_copyright ) : '© ' . gmdate( 'Y' ) . ' ' . get_bloginfo( 'name' );
		?>
		<span><?php echo esc_html( $pa_copyright ); ?></span>
	</div>
</footer>

<?php wp_footer(); ?>
</body>
</html>
