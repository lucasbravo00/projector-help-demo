<?php
/**
 * Projector Academy — child theme of Hello Elementor.
 *
 * Provides the branded header/footer, the menus they render and the stylesheet
 * with the component classes (pa-*) that the Elementor pages use.
 *
 * @package ProjectorAcademy
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

define( 'PA_THEME_DIR', get_stylesheet_directory() );
define( 'PA_THEME_URI', get_stylesheet_directory_uri() );

add_action(
	'after_setup_theme',
	function () {
		register_nav_menus(
			array(
				'pa-primary' => __( 'Header menu', 'projector-academy' ),
				'pa-footer'  => __( 'Footer menu', 'projector-academy' ),
			)
		);
	}
);

add_action(
	'wp_enqueue_scripts',
	function () {
		// The theme renders its own header/footer, so Hello's header/footer CSS is not needed.
		wp_dequeue_style( 'hello-elementor-header-footer' );

		wp_enqueue_style( 'pa-fonts', 'https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,400;0,500;0,600;0,700;0,800;1,400&display=swap', array(), null );

		$deps = array( 'hello-elementor-theme-style' );
		if ( wp_style_is( 'elementor-frontend', 'registered' ) ) {
			$deps[] = 'elementor-frontend';
		}
		$css = PA_THEME_DIR . '/assets/css/academy.css';
		wp_enqueue_style( 'projector-academy', PA_THEME_URI . '/assets/css/academy.css', $deps, (string) filemtime( $css ) );

		$js = PA_THEME_DIR . '/assets/js/academy.js';
		wp_enqueue_script( 'projector-academy', PA_THEME_URI . '/assets/js/academy.js', array(), (string) filemtime( $js ), true );
	},
	20
);

// Montserrat is loaded once by the theme; Elementor does not need to request it again.
add_filter( 'elementor/frontend/print_google_fonts', '__return_false' );

add_filter(
	'body_class',
	function ( $classes ) {
		$classes[] = 'pa-site';
		return $classes;
	}
);

add_action(
	'wp_head',
	function () {
		echo '<meta name="theme-color" content="#05070d">' . "\n";
	}
);

/**
 * Social profiles shown in the footer.
 *
 * @return array<int, array{label: string, url: string, icon: string}>
 */
function pa_social_links() {
	return apply_filters(
		'pa_social_links',
		array(
			array(
				'label' => 'Facebook',
				'url'   => 'https://www.facebook.com/projectorstreamingapp/',
				'icon'  => 'facebook',
			),
			array(
				'label' => 'Instagram',
				'url'   => 'https://www.instagram.com/projector.stream/',
				'icon'  => 'instagram',
			),
			array(
				'label' => 'LinkedIn',
				'url'   => 'https://www.linkedin.com/company/79791229/admin/feed/posts/',
				'icon'  => 'linkedin',
			),
			array(
				'label' => 'YouTube',
				'url'   => 'https://www.youtube.com/@ProjectorVideoStreaming',
				'icon'  => 'youtube',
			),
			array(
				'label' => 'TikTok',
				'url'   => 'https://www.tiktok.com/@projector.stream?lang=en',
				'icon'  => 'tiktok',
			),
		)
	);
}

/**
 * Inline SVG for the footer social icons.
 *
 * @param string $name Icon key.
 * @return string
 */
function pa_social_icon( $name ) {
	$paths = array(
		'facebook'  => '<path d="M14 8.5V6.8c0-.8.5-1.3 1.3-1.3H17V2.3C16.4 2.2 15.3 2 14 2c-2.9 0-4.6 1.7-4.6 4.6v1.9H6.5v3.3h2.9V22h3.7V11.8h3l.5-3.3H14z" fill="currentColor"/>',
		'instagram' => '<rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" stroke-width="2"/><circle cx="17.4" cy="6.6" r="1.2" fill="currentColor"/>',
		'linkedin'  => '<path d="M4.98 3.5a2.5 2.5 0 1 1 0 5 2.5 2.5 0 0 1 0-5zM3 9.75h4V21H3V9.75zm6.5 0h3.8v1.6h.06c.53-1 1.83-2.05 3.77-2.05 4.03 0 4.77 2.65 4.77 6.1V21h-4v-4.9c0-1.17-.02-2.68-1.63-2.68-1.64 0-1.89 1.28-1.89 2.6V21h-4V9.75z" fill="currentColor"/>',
		'youtube'   => '<path d="M22 8.2a3 3 0 0 0-2.1-2.1C18 5.6 12 5.6 12 5.6s-6 0-7.9.5A3 3 0 0 0 2 8.2 31 31 0 0 0 1.6 12c0 1.3.1 2.6.4 3.8a3 3 0 0 0 2.1 2.1c1.9.5 7.9.5 7.9.5s6 0 7.9-.5a3 3 0 0 0 2.1-2.1c.3-1.2.4-2.5.4-3.8s-.1-2.6-.4-3.8zM10 15.2V8.8l5.2 3.2L10 15.2z" fill="currentColor"/>',
		'tiktok'    => '<path d="M16.6 2h-3.3v13.3a2.9 2.9 0 1 1-2.1-2.8V9.1a6.2 6.2 0 1 0 5.4 6.2V8.6a7.6 7.6 0 0 0 4.4 1.4V6.7a4.4 4.4 0 0 1-4.4-4.7z" fill="currentColor"/>',
	);
	$path  = isset( $paths[ $name ] ) ? $paths[ $name ] : '';
	return '<svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true" focusable="false">' . $path . '</svg>';
}
